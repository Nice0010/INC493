// generated from rosidl_generator_c/resource/idl.h.em
// with input from vesc_msgs:msg/VescImuStamped.idl
// generated code does not contain a copyright notice

#ifndef VESC_MSGS__MSG__VESC_IMU_STAMPED_H_
#define VESC_MSGS__MSG__VESC_IMU_STAMPED_H_

#include "vesc_msgs/msg/detail/vesc_imu_stamped__struct.h"
#include "vesc_msgs/msg/detail/vesc_imu_stamped__functions.h"
#include "vesc_msgs/msg/detail/vesc_imu_stamped__type_support.h"

#endif  // VESC_MSGS__MSG__VESC_IMU_STAMPED_H_
