// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef VESC_MSGS__MSG__VESC_STATE_HPP_
#define VESC_MSGS__MSG__VESC_STATE_HPP_

#include "vesc_msgs/msg/detail/vesc_state__struct.hpp"
#include "vesc_msgs/msg/detail/vesc_state__builder.hpp"
#include "vesc_msgs/msg/detail/vesc_state__traits.hpp"
#include "vesc_msgs/msg/detail/vesc_state__type_support.hpp"

#endif  // VESC_MSGS__MSG__VESC_STATE_HPP_
